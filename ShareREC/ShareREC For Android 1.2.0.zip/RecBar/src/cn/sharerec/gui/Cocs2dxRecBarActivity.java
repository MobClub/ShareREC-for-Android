package cn.sharerec.gui;

import org.cocos2dx.lib.Cocos2dxActivity;
import org.cocos2dx.lib.Cocos2dxGLSurfaceView;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import cn.sharerec.recorder.impl.Cocos2DRecorder;

public abstract class Cocs2dxRecBarActivity extends Cocos2dxActivity {
	private Cocos2dxGLSurfaceView view;
	private RecBar recBar;
	private Cocos2DRecorder recorder;
	
	protected void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		
		ViewGroup vg = (ViewGroup) view.getParent();
		recBar = new RecBar(this);
		recorder = Cocos2DRecorder.getInstance(getAppkey());
		recorder.setMaxFrameSize(Cocos2DRecorder.LevelMaxFrameSize.LEVEL_1920_1080);
		recorder.setBitRate(2000000);
		recBar.setRecorder(recorder);
		ViewGroup.LayoutParams lp = new ViewGroup.LayoutParams(
				LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
		vg.addView(recBar, lp);
		
		hideRecBar();
	}
	
	protected abstract String getAppkey();
	
	public Cocos2dxGLSurfaceView onCreateView() {
		view = Cocos2DRecorder.getCocos2dxGLSurfaceView(getAppkey());
		return view;
	}
	
	protected final void showRecBar() {
		recBar.setVisibility(View.VISIBLE);
	}
	
	protected final void hideRecBar() {
		recBar.setVisibility(View.GONE);
	}
	
	protected final void setRecBarAnchor(int anchor) {
		recBar.setAnchor(anchor);
	}
	
	protected final void setRecBarScale(float scale) {
		recBar.setScale(scale);
	}
	
	protected final void setShareText(String text) {
		recorder.setText(text);
	}
	
	protected final void addShareCustomAttr(String key, String value) {
		recorder.addAttrData(key, value);
	}
	
	protected void onPause() {
		recBar.pause();
		super.onPause();
	}
	
	protected void onResume() {
		super.onResume();
		recBar.resume();
	}
	
}
