package cn.sharerec.gui;

import com.mob.tools.utils.R;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.os.Handler;
import android.os.Handler.Callback;
import android.os.Message;
import android.view.MotionEvent;
import android.view.View;

public class RecIcon extends Layer implements Callback {
	private static final int MSG_SHOW_ICON = 1;
	private static final int MSG_HIDE_ICON = 2;
	private static final int MSG_SHOW_ALPHA = 3;
	private static final int MSG_SHOW_RECORDING = 4;
	
	private int state;
	private float scale;
	private int anchor;
	
	private float left;
	private float top;
	private float right;
	private float bottom;
	
	private boolean showingOrHiding;
	private boolean touched;
	private boolean moving;
	private float movingX;
	private float movingY;
	private boolean showAplha;
	private boolean flashRed;
	
	private int frameCount;
	private int frameInterval;
	private float[] table;
	private int progress;
	private Handler handler;
	
 	public RecIcon(RecBar bar) {
		super(bar);
		scale = 0.4f;
		handler = new Handler(this);
	}
 	
	public void setDuration(int duration, int fps) {
		frameInterval = 1000 / fps;
		frameCount = (int) (5f * duration * fps / 9000 + 0.5f);
		table = new float[frameCount + 1];
		for (int i = 0; i < frameCount; i++) {
			float x = ((float) i) / frameCount;
			table[i] = x - (float) (Math.cos(2 * Math.PI * x) / 3) + 1.0f / 3;
		}
		table[frameCount] = 1;
	}
	
	public void setState(int state) {
		this.state = state;
		if (state == RecBar.STATE_RECORDING) {
			handler.sendEmptyMessageDelayed(MSG_SHOW_RECORDING, 667);
		}
	}

	public void setScale(float scale) {
		this.scale = scale;
	}

	public void setAnchor(int anchor) {
		this.anchor = anchor;
	}
	
	protected int getLeft() {
		return (int) left;
	}
	
	protected int getTop() {
		return (int) top;
	}
	
	protected int getRight() {
		return (int) right;
	}
	
	protected int getBottom() {
		return (int) bottom;
	}
	
	protected void onLayout() {
		int barWidth = bar.getWidth();
		int barHeight = bar.getHeight();
		float shortSize = barWidth;
		if (shortSize > barHeight) {
			shortSize = barHeight;
		}
		float bmWidth = shortSize * scale / 3;
		
		if (!moving) {
			switch (anchor) {
				case RecBar.ANCHOR_TOP: {
					left = (barWidth - bmWidth) / 2;
					top = 0;
				} break;
				case RecBar.ANCHOR_RIGHT: {
					left = barWidth - bmWidth;
					top = (barHeight - bmWidth) / 2;
				} break;
				case RecBar.ANCHOR_BOTTOM: {
					left = (barWidth - bmWidth) / 2;
					top = barHeight - bmWidth;
				} break;
				default: {
					left = 0;
					top = (barHeight - bmWidth) / 2;
				} break;
			}
		}
		
		right = left + bmWidth;
		bottom = top + bmWidth;
	}
	
	protected boolean onTouchEvent(MotionEvent event) {
		if (showingOrHiding) {
			return false;
		}
		
		switch (event.getAction()) {
			case MotionEvent.ACTION_DOWN: {
				touched = isTouched(event);
				return touched;
			}
			case MotionEvent.ACTION_MOVE: {
				if (moving) {
					left += (event.getX() - movingX);
					top += (event.getY() - movingY);
					movingX = event.getX();
					movingY = event.getY();
					invalidate();
				} else {
					touched = isTouched(event);
					if (!touched) {
						moving = true;
						movingX = event.getX();
						movingY = event.getY();
						invalidate();
					}
				}
				return false;
			}
			case MotionEvent.ACTION_UP: {
				if (touched) {
					touched = false;
					return onUp(event);
				} else if (moving) {
					moving = false;
					onAnchorChange();
					progress = frameCount;
					invalidate();
					return false;
				}
			}
		}
		
		return false;
	}
	
	private boolean isTouched(MotionEvent e) {
		float x = e.getX();
		float y = e.getY();
		return x >= left && x <= right && y >= top && y <= bottom;
	}
	
	private boolean onUp(MotionEvent e) {
		if (!isTouched(e)) {
			return false;
		}

		if (state == RecBar.STATE_IDLE) {
			bar.onShowRecMenu();
		} else {
			bar.onStopRecord();
		}
		return true;
	}
	
	private void onAnchorChange() {
		int barWidth = bar.getWidth();
		int barHeight = bar.getHeight();
		int centerX = barWidth / 2;
		int centerY = barHeight / 2;
		float bmCenterX = (right + left) / 2;
		float bmCenterY = (bottom + top) / 2;
		if (bmCenterY < centerY) { // 左上右
			if (bmCenterX < centerX) { // 左上
				if (bmCenterY * centerX < centerY * bmCenterX) { // 上
					bar.setAnchor(RecBar.ANCHOR_TOP);
				} else { // 左
					bar.setAnchor(RecBar.ANCHOR_LEFT);
				}
			} else { // 右上
				if (bmCenterY * centerX < centerY * (barWidth - bmCenterX)) { // 上
					bar.setAnchor(RecBar.ANCHOR_TOP);
				} else { // 右
					bar.setAnchor(RecBar.ANCHOR_RIGHT);
				}
			}
		} else { // 左下右
			if (bmCenterX < centerX) { // 左下
				if ((barHeight - bmCenterY) * centerX < centerY * bmCenterX) { // 下
					bar.setAnchor(RecBar.ANCHOR_BOTTOM);
				} else { // 左
					bar.setAnchor(RecBar.ANCHOR_LEFT);
				}
			} else { // 右下
				if ((barHeight - bmCenterY) * centerX < centerY * (barWidth - bmCenterX)) { // 下
					bar.setAnchor(RecBar.ANCHOR_BOTTOM);
				} else { // 右
					bar.setAnchor(RecBar.ANCHOR_RIGHT);
				}
			}
		}
		
		showAplha = false;
		handler.sendEmptyMessageDelayed(MSG_SHOW_ALPHA, 3000);
	}
	
	protected void onDraw(Canvas canvas) {
		Paint paint = new Paint();
		paint.setAntiAlias(true);
		
		if (state == RecBar.STATE_IDLE) {
			drawIdel(canvas, paint);
		} else {
			drawRecording(canvas, paint);
		}
	}
	
	private void drawIdel(Canvas canvas, Paint paint) {
		float radius = getWidth() / 2;
		Path path = new Path();
		path.moveTo(0.6f * radius, 0.75f * radius);
		path.lineTo(1.2f * radius, 0.75f * radius);
		path.lineTo(1.2f * radius, 0.90f * radius);
		path.lineTo(1.4f * radius, 0.80f * radius);
		path.lineTo(1.4f * radius, 1.20f * radius);
		path.lineTo(1.2f * radius, 1.10f * radius);
		path.lineTo(1.2f * radius, 1.25f * radius);
		path.lineTo(0.6f * radius, 1.25f * radius);
		if (moving) {
			paint.setColor(0x9a157ed6);
			canvas.drawCircle(left + radius, top + radius, radius, paint);
			path.offset(left, top);
			paint.setColor(0xe6ffffff);
		} else {
			paint.setColor(showAplha ? 0x2e157ed6 : 0x9a157ed6);
			switch (anchor) {
				case RecBar.ANCHOR_TOP: {
					canvas.drawCircle(left + radius, top + (table[progress] - 1) * radius, radius, paint);
					path.offset(left, top + (table[progress] - 1.6f) * radius);
				} break;
				case RecBar.ANCHOR_RIGHT: {
					canvas.drawCircle(left + (3 - table[progress]) * radius, top + radius, radius, paint);
					path.offset(left + (1.55f - table[progress]) * radius, top);
				} break;
				case RecBar.ANCHOR_BOTTOM: {
					canvas.drawCircle(left + radius, top + (3 - table[progress]) * radius, radius, paint);
					path.offset(left, top + (1.6f - table[progress]) * radius);
				} break;
				default: {
					canvas.drawCircle(left + (table[progress] - 1) * radius, top + radius, radius, paint);
					path.offset(left + (table[progress] - 1.55f) * radius, top);
				} break;
			}
			paint.setColor(showAplha ? 0x45ffffff : 0xe6ffffff);
		}
		canvas.drawPath(path, paint);
	}
	
	private void drawRecording(Canvas canvas, Paint paint) {
		String label;
		if (isInEditMode()) {
			label = String.valueOf(new char[] {0x505c, 0x6b62});
		} else {
			int resId = R.getStringRes(getContext(), "srec_recbar_stop");
			label = getContext().getString(resId);
		}
		paint.setColor(0xff787878);
		float textSize = getWidth() / 4;
		paint.setTextSize(textSize);
		
		float padding = R.dipToPx(getContext(), 5) * scale;
		float bmHeight = padding * 2 + textSize + paint.getFontMetrics().bottom;
		float bmTop;
		switch (anchor) {
			case RecBar.ANCHOR_TOP: bmTop = top; break;
			case RecBar.ANCHOR_BOTTOM: bmTop = bottom - bmHeight; break;
			default: bmTop = (top + bottom - bmHeight) / 2; break;
		}
		paint.setColor(0xcde9e9e9);
		canvas.drawRect(left + padding, bmTop + padding, right - padding, bmTop + bmHeight - padding, paint);
		
		float dotBound = R.dipToPx(getContext(), 2) * scale;
		float dotHeight = bmHeight / 2 + dotBound * 2;
		float dotPadding = (bmHeight - dotHeight) / 2;
		float dotLeft = left + dotPadding;
		float dotTop = bmTop + dotPadding;
		paint.setColor(0xff787878);
		canvas.drawRect(dotLeft, dotTop, dotLeft + dotHeight, dotTop + dotHeight, paint);
		
		float rDotHeight = dotHeight - dotBound * 2;
		float rDotLeft = left + (bmHeight - rDotHeight) / 2;
		float rDotTop = bmTop + (bmHeight - rDotHeight) / 2;
		paint.setColor(flashRed ? 0xffff0000 : 0xffff9999);
		canvas.drawRect(rDotLeft, rDotTop, rDotLeft + rDotHeight, rDotTop + rDotHeight, paint);
		
		float txtLeft = dotLeft + dotHeight + dotBound * 2;
		float txtRight = right - dotPadding;
		float txtHeight = paint.getFontMetrics().descent + paint.getFontMetrics().ascent;
		float txtTop = bmTop + (bmHeight - txtHeight) / 2;
		float tw = paint.measureText(label);
		paint.setColor(0xff323232);
		if (tw < txtRight - txtLeft) {
			canvas.drawText(label, txtRight - tw, txtTop, paint);
		} else {
			canvas.save();
			canvas.clipRect(txtLeft, bmTop, txtRight, bmTop + bmHeight);
			canvas.drawText(label, txtLeft, txtTop, paint);
			canvas.restore();
		}
	}
	
	public void show(final Runnable afterShown) {
		if (showingOrHiding) {
			return;
		}
		
		showingOrHiding = true;
		new Thread() {
			public void run() {
				int msg = MSG_SHOW_ICON;
				progress = -1;
				int count = frameCount - 1;
				for (int i = 0; i < count; i++) {
					handler.sendEmptyMessageDelayed(msg, frameInterval * i);
				}
				Message m = new Message();
				m.what = msg;
				m.obj = afterShown;
				handler.sendMessageDelayed(m, frameInterval * count);
			}
		}.start();
	}
	
	public void hide(final Runnable afterHide) {
		if (showingOrHiding) {
			return;
		}
		
		new Thread() {
			public void run() {
				int msg = MSG_HIDE_ICON;
				int count = frameCount - 1;
				progress = count + 1;
				for (int i = 0; i < count; i++) {
					handler.sendEmptyMessageDelayed(msg, frameInterval * i);
				}
				Message m = new Message();
				m.what = msg;
				m.obj = afterHide;
				handler.sendMessageDelayed(m, frameInterval * count);
			}
		}.start();
	}
	
	public boolean handleMessage(Message msg) {
		switch(msg.what) {
			case MSG_SHOW_ICON: {
				showAplha = false;
				progress++;
				if (progress <= 0) {
					setVisibility(View.VISIBLE);
				}
				invalidate();
				if (progress >= frameCount - 1) {
					showingOrHiding = false;
					if (msg.obj != null) {
						((Runnable) msg.obj).run();
					}
					handler.sendEmptyMessageDelayed(MSG_SHOW_ALPHA, 3000);
				}
			} break;
			case MSG_HIDE_ICON: {
				showAplha = false;
				if (progress > 0) {
					progress--;
				}
				invalidate();
				if (progress <= 0) {
					showingOrHiding = false;
					setVisibility(View.GONE);
					if (msg.obj != null) {
						((Runnable) msg.obj).run();
					}
				}
			} break;
			case MSG_SHOW_ALPHA: {
				showAplha = true;
				invalidate();
			} break;
			case MSG_SHOW_RECORDING: {
				flashRed = !flashRed;
				invalidate();
				if (state == RecBar.STATE_RECORDING) {
					handler.sendEmptyMessageDelayed(MSG_SHOW_RECORDING, 667);
				}
			} break;
		}
		
		return false;
	}
	
}
