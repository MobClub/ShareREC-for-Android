package cn.sharerec.gui;

import java.lang.reflect.Field;
import java.util.ArrayList;
import android.os.Handler.Callback;
import android.os.Message;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import cn.sharerec.recorder.impl.UnityRecorder;
import com.mob.tools.utils.UIHandler;
import com.unity3d.player.UnityPlayer;

public class Unity3DRecBar implements Callback {
	private static final int MSG_INIT = 1;
	private static final int MSG_SET_RECORDER = 2;
	private static final int MSG_SET_RECBAR_CALLBACK = 3;
	private static final int MSG_SHOW_RECBAR = 4;
	private static final int MSG_HIDE_RECBAR = 5;
	private static final int MSG_SET_RECBAR_ANCHOR = 6;
	private static final int MSG_SET_RECBAR_SCALE = 7;
	private static final int MSG_SET_SHARE_TEXT = 8;
	private static final int MSG_ADD_SHARE_CUSTOM_ATTR = 9;
	private static final int MSG_PAUSE = 10;
	private static final int MSG_RESUME = 11;
	
	private RecBar recBar;
	private UnityRecorder recorder;
	private String bufText;
	
	public Unity3DRecBar() {
		UIHandler.sendEmptyMessage(MSG_INIT, this);
	}
	
	public void setRecorder(UnityRecorder recorder) {
		Message msg = new Message();
		msg.what = MSG_SET_RECORDER;
		msg.obj = recorder;
		UIHandler.sendMessage(msg, this);
	}
	
	public void setRecBarCallback(String gameObject, String callback) {
		Message msg = new Message();
		msg.what = MSG_SET_RECBAR_CALLBACK;
		msg.obj = new Object[] {gameObject, callback};
		UIHandler.sendMessage(msg, this);
	}
	
	public void showRecBar() {
		UIHandler.sendEmptyMessage(MSG_SHOW_RECBAR, this);
	}
	
	public void hideRecBar() {
		UIHandler.sendEmptyMessage(MSG_HIDE_RECBAR, this);
	}
	
	public void setRecBarAnchor(int anchor) {
		Message msg = new Message();
		msg.what = MSG_SET_RECBAR_ANCHOR;
		msg.arg1 = anchor;
		UIHandler.sendMessage(msg, this);
	}
	
	public void setRecBarScale(float scale) {
		Message msg = new Message();
		msg.what = MSG_SET_RECBAR_SCALE;
		msg.obj = scale;
		UIHandler.sendMessage(msg, this);
	}
	
	public void setShareText(String text) {
		Message msg = new Message();
		msg.what = MSG_SET_SHARE_TEXT;
		msg.obj = text;
		UIHandler.sendMessage(msg, this);
	}
	
	public void addShareCustomAttr(String key, String value) {
		Message msg = new Message();
		msg.what = MSG_ADD_SHARE_CUSTOM_ATTR;
		msg.obj = new Object[] {key, value};
		UIHandler.sendMessage(msg, this);
	}
	
	public void onPause() {
		UIHandler.sendEmptyMessage(MSG_PAUSE, this);
	}
	
	public void onResume() {
		UIHandler.sendEmptyMessage(MSG_RESUME, this);
	}
	
	public boolean handleMessage(Message msg) {
		switch (msg.what) {
			case MSG_INIT: {
				UnityPlayer player = getPalyer();
				ViewGroup vg = (ViewGroup) player.getParent();
				recBar = new RecBar(player.getContext());
				ViewGroup.LayoutParams lp = new ViewGroup.LayoutParams(
						LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
				vg.addView(recBar, lp);
				hideRecBar();
			} break;
			case MSG_SET_RECORDER: {
				this.recorder = (UnityRecorder) msg.obj;
				recBar.setRecorder(recorder);
				if (bufText != null) {
					recorder.setText(bufText);
				}
			} break;
			case MSG_SET_RECBAR_CALLBACK: {
				Object[] objs = (Object[]) msg.obj;
				recBar.setCallback((String) objs[0], (String) objs[1]);
			} break;
			case MSG_SHOW_RECBAR: {
				recBar.setVisibility(View.VISIBLE);
				recBar.bringToFront();
				recBar.requestFocus();
			} break;
			case MSG_HIDE_RECBAR: {
				recBar.setVisibility(View.GONE);
			} break;
			case MSG_SET_RECBAR_ANCHOR: {
				recBar.setAnchor(msg.arg1);
			} break;
			case MSG_SET_RECBAR_SCALE: {
				recBar.setScale((Float) msg.obj);
			} break;
			case MSG_SET_SHARE_TEXT: {
				bufText = (String) msg.obj;
				if (recorder != null) {
					recorder.setText(bufText);
				}
			} break;
			case MSG_ADD_SHARE_CUSTOM_ATTR: {
				Object[] objs = (Object[]) msg.obj;
				recorder.addAttrData((String) objs[0], (String) objs[1]);
			} break;
			case MSG_PAUSE: {
				recBar.pause();
			} break;
			case MSG_RESUME: {
				recBar.resume();
			} break;
		}
		return false;
	}
	
	private UnityPlayer getPalyer() {
		try {
			ArrayList<Class<?>> clsList = new ArrayList<Class<?>>();
			Class<?> cls = UnityPlayer.currentActivity.getClass();
			clsList.add(cls);
			cls = cls.getSuperclass();
			while (cls != null) {
				clsList.add(cls);
				cls = cls.getSuperclass();
			}
			
			for (Class<?> c : clsList) {
				Field[] flds = c.getDeclaredFields();
				for (Field fld : flds) {
					if (UnityPlayer.class.equals(fld.getType())) {
						fld.setAccessible(true);
						return (UnityPlayer) fld.get(UnityPlayer.currentActivity);
					}
				}
			}
		} catch (Throwable t) {}
		return null;
	}
	
}
