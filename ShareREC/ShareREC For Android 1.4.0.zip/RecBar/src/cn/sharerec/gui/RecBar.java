package cn.sharerec.gui;

import android.content.Context;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;
import cn.sharerec.recorder.OnRecorderStateListener;
import cn.sharerec.recorder.Recorder;
import cn.sharerec.recorder.impl.Cocos2DRecorder;
import cn.sharerec.recorder.impl.UnityRecorder;

import com.mob.tools.utils.R;
import com.unity3d.player.UnityPlayer;

public class RecBar extends View {
	public static final int ANCHOR_LEFT = 0;
	public static final int ANCHOR_RIGHT = 1;
	public static final int ANCHOR_TOP = 2;
	public static final int ANCHOR_BOTTOM = 3;
	
	public static final int STATE_IDLE = 0;
	public static final int STATE_RECORDING = 1;
	
	
	private RecIcon icon = null;
	private RecMenu menu = null;
	private Recorder recorder;
	private long startTime;
	private String gameObject;
	private String callback;

	public RecBar(Context context) {
		super(context);
		init(context);
	}

	public RecBar(Context context, AttributeSet attrs) {
		super(context, attrs);
		init(context);
	}

	public RecBar(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		init(context);
	}
	
	private void init(Context context) {
		if (icon == null) {
			icon = new RecIcon(this);
			icon.setDuration(500, 60);
			icon.setVisibility(GONE);
		}
		if (menu == null) {
			menu = new RecMenu(this);
			menu.setDuration(500, 60);
			menu.setVisibility(GONE);
		}
	}
	
	public void onShowRecMenu() {
		icon.hide(new Runnable() {
			public void run() {
				menu.show();
			}
		});
	}
	
	public void onCloseRecMenu() {
		menu.hide(new Runnable() {
			public void run() {
				icon.show(null);
			}
		});
	}

	public void onShowVideoCenter() {
		menu.hide(new Runnable() {
			public void run() {
				icon.show(new Runnable() {
					public void run() {
						if (recorder != null && recorder instanceof Cocos2DRecorder) {
							((Cocos2DRecorder) recorder).showVideoCenter();
						} else if (recorder != null && recorder instanceof UnityRecorder) {
							UnityPlayer.UnitySendMessage(gameObject, callback, String.valueOf(4));
						}
					}
				});
			}
		});
	}

	public void onStartRecord() {
		menu.hide(new Runnable() {
			public void run() {
				icon.setVisibility(VISIBLE);
				if (recorder == null) {
					postInvalidate();
				} else {
					if (recorder instanceof UnityRecorder) {
						UnityPlayer.UnitySendMessage(gameObject, callback, String.valueOf(2));
						startTime = System.currentTimeMillis();
						icon.setState(STATE_RECORDING);
						postInvalidate();
					} else if (recorder.isAvailable()) {
						recorder.setOnRecorderStateListener(getOnRecorderStateListener());
						recorder.start();
					}
				}
			}
		});
	}

	private OnRecorderStateListener getOnRecorderStateListener() {
		return new OnRecorderStateListener() {
			private boolean isResuming;
			
			public void onStateChange(Recorder recorder, int state) {
				if (state == Recorder.STATE_PAUSING) {
					isResuming = true;
				} else if (state == Recorder.STATE_STARTED) {
					if (!isResuming) {
						startTime = System.currentTimeMillis();
						icon.setState(STATE_RECORDING);
						postInvalidate();
					}
					isResuming = false;
				} else if (state == Recorder.STATE_STOPPED) {
					icon.setState(STATE_IDLE);
					icon.show(new Runnable() {
						public void run() {
							showShare();
						}
					});
				}
			}
		};
	}
	
	public void onStopRecord() {
		
		if (recorder == null) {
			return;
		}
		if (System.currentTimeMillis() - startTime < recorder.getMinDuration()) {
			post(new Runnable() {
				public void run() {
					int resId = R.getStringRes(getContext(), "srec_duration_of_video_must_longger_than_4_secends");
					Toast.makeText(getContext(), resId, Toast.LENGTH_SHORT).show();
				}
			});
			return;
		}
		
		if (recorder instanceof UnityRecorder) {
			icon.setState(STATE_IDLE);
			icon.show(new Runnable() {
				public void run() {
					UnityPlayer.UnitySendMessage(gameObject, callback,String.valueOf(3));
				}
			});
		} else {
			recorder.stop();
		}
	}
	
	public void onShowMyVideo() {
		menu.hide(new Runnable() {
			public void run() {
				icon.show(new Runnable() {
					public void run() {
						if (recorder != null && recorder instanceof Cocos2DRecorder) {
							((Cocos2DRecorder) recorder).showProfile();
						} else if (recorder != null && recorder instanceof UnityRecorder) {
							UnityPlayer.UnitySendMessage(gameObject, callback, String.valueOf(1));
						}
					}
				});
			}
		});
	}
	
	private void showShare() {
		if (recorder instanceof Cocos2DRecorder) {
			((Cocos2DRecorder) recorder).showShare();
		}/* else if (recorder instanceof UnityRecorder) {
			((UnityRecorder) recorder).showShare();
		}*/
	}
	
	public void setAnchor(int anchor) {
		icon.setAnchor(anchor);
		menu.setAnchor(anchor);
		postInvalidate();
	}
	
	public void setScale(float scale) {
		icon.setScale(scale);
		menu.setScale(scale);
		postInvalidate();
	}
	
	public void setRecorder(Recorder recorder) {
		this.recorder = recorder;
	}
	
	public void setCallback(String gameObject, String callback) {
		this.gameObject = gameObject;
		this.callback = callback;
	}
	
	public void setVisibility(int visibility) {
		super.setVisibility(visibility);
		icon.show(null);
	}
	
	protected void onDraw(Canvas canvas) {
		menu.draw(canvas);
		icon.draw(canvas);
	}
	
	public boolean onTouchEvent(MotionEvent event) {
		boolean res = icon.touch(event);
		if (!res) {
			res = menu.touch(event);
		}
		
		return res ? res : super.onTouchEvent(event);
	}
	
	public RecIcon getIcon() {
		return icon;
	}

	public void pause() {
		if (recorder != null) {
			recorder.pause();
		}
	}
	
	public void resume() {
		if (recorder != null) {
			recorder.resume();
		}
	}
	
}
