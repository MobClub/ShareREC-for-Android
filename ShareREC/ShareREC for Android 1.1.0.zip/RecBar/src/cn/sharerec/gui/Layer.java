package cn.sharerec.gui;

import android.content.Context;
import android.graphics.Canvas;
import android.view.MotionEvent;
import android.view.View;

public class Layer {
	protected RecBar bar;
	protected int visibility;
	
	public Layer(RecBar bar) {
		this.bar = bar;
		visibility = View.VISIBLE;
	}
	
	public void setVisibility(int visibility) {
		this.visibility = visibility;
		bar.invalidate();
	}
	
	protected int getLeft() {
		return 0;
	}
	
	protected int getTop() {
		return 0;
	}
	
	protected int getRight() {
		return bar.getWidth();
	}
	
	protected int getBottom() {
		return bar.getHeight();
	}
	
	protected final int getWidth() {
        return getRight() - getLeft();
    }
    
    protected final int getHeight() {
        return getBottom() - getTop();
    }
    
    protected final Context getContext() {
        return bar.getContext();
    }
    
	public void invalidate() {
		bar.invalidate();
	}
	
	public void draw(Canvas canvas) {
		if (visibility == View.VISIBLE) {
			canvas.save();
			onLayout();
			canvas.clipRect(getLeft(), getTop(), getRight(), getBottom());
			onDraw(canvas);
			canvas.restore();
		}
	}
	
	protected void onLayout() {
		
	}
	
	protected void onDraw(Canvas canvas) {
		
	}
	
	public boolean touch(MotionEvent event) {
		if (visibility == View.VISIBLE) {
			return onTouchEvent(event);
		}
		return false;
	}
	
	protected boolean onTouchEvent(MotionEvent event) {
		return false;
	}
	
	protected boolean isInEditMode() {
		return bar.isInEditMode();
	}
	
}
