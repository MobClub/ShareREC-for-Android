package cn.sharerec.gui;

import java.lang.reflect.Field;
import java.util.ArrayList;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import cn.sharerec.recorder.UnityRecorder;
import com.unity3d.player.UnityPlayer;
import com.unity3d.player.UnityPlayerActivity;

public class Unity3DRecBarActivity extends UnityPlayerActivity {
	private RecBar recBar;
	private UnityRecorder recorder;
	private String bufText;
	
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		UnityPlayer player = getPalyer();
		ViewGroup vg = (ViewGroup) player.getParent();
		recBar = new RecBar(this);
		ViewGroup.LayoutParams lp = new ViewGroup.LayoutParams(
				LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
		vg.addView(recBar, lp);
		
		hideRecBar();
	}
	
	private UnityPlayer getPalyer() {
		try {
			ArrayList<Class<?>> clsList = new ArrayList<Class<?>>();
			Class<?> cls = UnityPlayer.currentActivity.getClass();
			clsList.add(cls);
			cls = cls.getSuperclass();
			while (cls != null) {
				clsList.add(cls);
				cls = cls.getSuperclass();
			}
			
			for (Class<?> c : clsList) {
				Field[] flds = c.getDeclaredFields();
				for (Field fld : flds) {
					if (UnityPlayer.class.equals(fld.getType())) {
						fld.setAccessible(true);
						return (UnityPlayer) fld.get(UnityPlayer.currentActivity);
					}
				}
			}
		} catch (Throwable t) {}
		return null;
	}
	
	public void setRecorder(UnityRecorder recorder) {
		this.recorder = recorder;
		recBar.setRecorder(recorder);
		if (bufText != null) {
			recorder.setText(bufText);
		}
	}
	
	public void setRecBarCallback(String gameObject, String callback) {
		recBar.setCallback(gameObject, callback);
	}
	
	protected final void showRecBar() {
		recBar.setVisibility(View.VISIBLE);
		recBar.bringToFront();
		recBar.requestFocus();
	}
	
	protected final void hideRecBar() {
		recBar.setVisibility(View.GONE);
	}
	
	protected final void setRecBarAnchor(int anchor) {
		recBar.setAnchor(anchor);
	}
	
	protected final void setRecBarScale(float scale) {
		recBar.setScale(scale);
	}
	
	protected final void setShareText(String text) {
		bufText = text;
		if (recorder != null) {
			recorder.setText(text);
		}
	}
	
	protected final void addShareCustomAttr(String key, String value) {
		recorder.addAttrData(key, value);
	}
	
	protected void onPause() {
		recBar.pause();
		super.onPause();
	}
	
	protected void onResume() {
		super.onResume();
		recBar.resume();
	}
	
}
