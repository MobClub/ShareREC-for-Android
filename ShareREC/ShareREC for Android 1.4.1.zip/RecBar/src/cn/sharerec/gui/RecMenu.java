package cn.sharerec.gui;

import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.graphics.Xfermode;
import android.os.Handler;
import android.os.Handler.Callback;
import android.os.Message;
import android.view.MotionEvent;
import android.view.View;

import com.mob.tools.utils.R;

public class RecMenu extends Layer implements Callback {
	private static final int MSG_SHOW_MENU = 1;
	private static final int MSG_HIDE_MENU = 2;
	private static final int MSG_AUTO_HIDE = 3;
	
	private float scale;
	private int anchor;
	
	private float left;
	private float top;
	private float right;
	private float bottom;
	
	private int frameInterval;
	private int frameCount;
	private int[] nodes;
	private float[] table;
	private int progress;
	private boolean showingOrHiding;
	private boolean closingType;
	private Handler handler;
	
	private boolean touched;
	private float boundary;

	public RecMenu(RecBar bar) {
		super(bar);
		scale = 0.4f;
		handler = new Handler(this);
	}
	
	public void setDuration(int duration, int fps) {
		frameInterval = 1000 / fps;
		frameCount = duration * fps / 1000;
		nodes = new int[9];
		for (int i = 1; i < nodes.length; i++) {
			nodes[i] = frameCount * i / 9 - 1;
		}
		int tabLen = frameCount - nodes[4];
		table = new float[tabLen + 1];
		for (int i = 0; i < tabLen; i++) {
			float x = ((float) i) / tabLen;
			table[i] = x - (float) (Math.cos(2 * Math.PI * x) / 3) + 1.0f / 3;
		}
		table[tabLen] = 1;
	}
	
	public void setScale(float scale) {
		this.scale = scale;
	}

	public void setAnchor(int anchor) {
		this.anchor = anchor;
	}
	
	protected int getLeft() {
		return (int) (anchor == RecBar.ANCHOR_RIGHT ? (left + right) / 2 : left);
	}
	
	protected int getTop() {
		return (int) (anchor == RecBar.ANCHOR_BOTTOM ? (top + bottom) / 2 : top);
	}
	
	protected int getRight() {
		return (int) (anchor == RecBar.ANCHOR_LEFT ? (left + right) / 2 : right);
	}
	
	protected int getBottom() {
		return (int) (anchor == RecBar.ANCHOR_TOP ? (top + bottom) / 2 : bottom);
	}
	
	protected void onLayout() {
		int barWidth = bar.getWidth();
		int barHeight = bar.getHeight();
		float shortSize = barWidth;
		if (shortSize > barHeight) {
			shortSize = barHeight;
		}
		float bmWidth = shortSize * scale;
		boundary = bmWidth * bmWidth / 4;
		
		switch (anchor) {
			case RecBar.ANCHOR_TOP: {
				left = (barWidth - bmWidth) / 2;
				top = 0;
			} break;
			case RecBar.ANCHOR_RIGHT: {
				left = barWidth - bmWidth;
				top = (barHeight - bmWidth) / 2;
			} break;
			case RecBar.ANCHOR_BOTTOM: {
				left = (barWidth - bmWidth) / 2;
				top = barHeight - bmWidth;
			} break;
			default: {
				left = 0;
				top = (barHeight - bmWidth) / 2;
			} break;
		}
		
		right = left + bmWidth;
		bottom = top + bmWidth;
	}
	
	protected void onDraw(Canvas canvas) {
		Paint paint = new Paint();
		paint.setAntiAlias(true);
		float drwLeft;
		float drwTop;
		float drwRight;
		float drwBottom;
		switch (anchor) {
			case RecBar.ANCHOR_TOP: {
				drwLeft = left;
				drwTop = top;
				drwRight = right;
				drwBottom = (bottom + top) / 2;
			} break;
			case RecBar.ANCHOR_RIGHT: {
				drwLeft = (right + left) / 2;
				drwTop = top;
				drwRight = right;
				drwBottom = bottom;
			} break;
			case RecBar.ANCHOR_BOTTOM: {
				drwLeft = left;
				drwTop = (bottom + top) / 2;
				drwRight = right;
				drwBottom = bottom;
			} break;
			default: {
				drwLeft = left;
				drwTop = top;
				drwRight = (right + left) / 2;
				drwBottom = bottom;
			} break;
		}
		
		float bgHeight = (drwRight - drwLeft > drwBottom - drwTop) ? (drwRight - drwLeft) : (drwBottom - drwTop);
		drawOuterBg(canvas, paint, drwLeft, drwTop, drwRight, drwBottom, bgHeight);
		drawInnerBg(canvas, paint, drwLeft, drwTop, drwRight, drwBottom, bgHeight);
		drawBgLines(canvas, paint, drwLeft, drwTop, drwRight, drwBottom, bgHeight);
		drawReturnArr(canvas, paint, drwLeft, drwTop, drwRight, drwBottom, bgHeight);
		
		if (progress >= nodes[4]) {
			drawProfile(canvas, paint, drwLeft, drwTop, drwRight, drwBottom, bgHeight);
			drawRec(canvas, paint, drwLeft, drwTop, drwRight, drwBottom, bgHeight);
			drawVideoCenter(canvas, paint, drwLeft, drwTop, drwRight, drwBottom, bgHeight);
		}
	}
	
	private void drawOuterBg(Canvas canvas, Paint paint, float drwLeft, float drwTop, float drwRight, float drwBottom, float bgHeight) {
		paint.setColor(0x9a009dd9);
		if (progress >= nodes[7]) {
			float centerX;
			float centerY;
			switch (anchor) {
				case RecBar.ANCHOR_TOP: {
					centerX = (drwRight + drwLeft) / 2;
					centerY = drwTop;
				} break;
				case RecBar.ANCHOR_RIGHT: {
					centerX = drwRight;
					centerY = (drwBottom + drwTop) / 2;
				} break;
				case RecBar.ANCHOR_BOTTOM: {
					centerX = (drwRight + drwLeft) / 2;
					centerY = drwBottom;
				} break;
				default: {
					centerX = drwLeft;
					centerY = (drwBottom + drwTop) / 2;
				} break;
			}
			float radius = bgHeight / 2;
			canvas.drawCircle(centerX, centerY, radius, paint);
		} else if (progress >= nodes[2]) {
			float startAngle;
			float sweepAngle;
			RectF rect;
			switch (anchor) {
				case RecBar.ANCHOR_TOP: {
					startAngle = 180;
					sweepAngle = -180;
					rect = new RectF(drwLeft, -drwBottom, drwRight, drwBottom);
				} break;
				case RecBar.ANCHOR_RIGHT: {
					startAngle = -90;
					sweepAngle = -180;
					rect = new RectF(drwLeft, drwTop, 2 * drwRight - drwLeft, drwBottom);
				} break;
				case RecBar.ANCHOR_BOTTOM: {
					startAngle = 180;
					sweepAngle = 180;
					rect = new RectF(drwLeft, drwTop, drwRight, 2 * drwBottom - drwTop);
				} break;
				default: {
					startAngle = -90;
					sweepAngle = 180;
					rect = new RectF(-drwRight, drwTop, drwRight, drwBottom);
				} break;
			}
			if (closingType) {
				canvas.drawArc(rect, startAngle - 180, (progress - nodes[2] + 1) * sweepAngle / (nodes[2] - nodes[6]), true, paint);
			} else {
				canvas.drawArc(rect, startAngle, (progress - nodes[2] + 1) * sweepAngle / (nodes[6] - nodes[2]), true, paint);
			}
		}
	}
	
	private void drawInnerBg(Canvas canvas, Paint paint, float drwLeft, float drwTop, float drwRight, float drwBottom, float bgHeight) {
		float iR = bgHeight / 6;
		float centerX;
		float centerY;
		switch (anchor) {
			case RecBar.ANCHOR_TOP: {
				centerX = (drwRight + drwLeft) / 2;
				centerY = drwTop + (progress >= nodes[5] ? 0 : (table[progress] - 1) * iR);
			} break;
			case RecBar.ANCHOR_RIGHT: {
				centerX = drwRight - (progress >= nodes[5] ? 0 : (table[progress] - 1) * iR);
				centerY = (drwBottom + drwTop) / 2;
			} break;
			case RecBar.ANCHOR_BOTTOM: {
				centerX = (drwRight + drwLeft) / 2;
				centerY = drwBottom - (progress >= nodes[5] ? 0 : (table[progress] - 1) * iR);
			} break;
			default: {
				centerX = drwLeft + (progress >= nodes[5] ? 0 : (table[progress] - 1) * iR);
				centerY = (drwBottom + drwTop) / 2;
			} break;
		}
		
		Xfermode backM = paint.getXfermode();
		paint.setXfermode(new PorterDuffXfermode(Mode.SRC_OUT));
		paint.setColor(0);
		canvas.drawCircle(centerX, centerY, iR, paint);
		paint.setXfermode(backM);
		paint.setColor(0xb3ffffff);
		canvas.drawCircle(centerX, centerY, iR, paint);
	}
	
	private void drawBgLines(Canvas canvas, Paint paint, float drwLeft, float drwTop, float drwRight, float drwBottom, float bgHeight) {
		if (progress >= nodes[7]) {
			float backSW = paint.getStrokeWidth();
			paint.setStrokeWidth(R.dipToPx(getContext(), 1));
			switch (anchor) {
				case RecBar.ANCHOR_TOP: {
					float beginX = drwLeft + 0.4083f * bgHeight;
					float beginY = drwTop + 0.1588f * bgHeight;
					float endX = drwLeft + 0.2583f * bgHeight;
					float endY = drwTop + 0.4186f * bgHeight;
					canvas.drawLine(beginX, beginY, endX, endY, paint);
					canvas.drawLine(2 * drwLeft + bgHeight - beginX, beginY, 2 * drwLeft + bgHeight - endX, endY, paint);
				} break;
				case RecBar.ANCHOR_RIGHT: {
					float beginX = drwRight - 0.1588f * bgHeight;
					float beginY = drwTop + 0.4083f * bgHeight;
					float endX = drwRight - 0.4186f * bgHeight;
					float endY = drwTop + 0.2583f * bgHeight;
					canvas.drawLine(beginX, beginY, endX, endY, paint);
					canvas.drawLine(beginX, 2 * drwTop + bgHeight - beginY, endX, 2 * drwTop + bgHeight - endY, paint);
				} break;
				case RecBar.ANCHOR_BOTTOM: {
					float beginX = drwLeft + 0.4083f * bgHeight;
					float beginY = drwBottom - 0.1588f * bgHeight;
					float endX = drwLeft + 0.2583f * bgHeight;
					float endY = drwBottom - 0.4186f * bgHeight;
					canvas.drawLine(beginX, beginY, endX, endY, paint);
					canvas.drawLine(2 * drwLeft + bgHeight - beginX, beginY, 2 * drwLeft + bgHeight - endX, endY, paint);
				} break;
				default: {
					float beginX = drwLeft + 0.1588f * bgHeight;
					float beginY = drwTop + 0.4083f * bgHeight;
					float endX = drwLeft + 0.4186f * bgHeight;
					float endY = drwTop + 0.2583f * bgHeight;
					canvas.drawLine(beginX, beginY, endX, endY, paint);
					canvas.drawLine(beginX, 2 * drwTop + bgHeight - beginY, endX, 2 * drwTop + bgHeight - endY, paint);
				} break;
			}
			paint.setStrokeWidth(backSW);
		}
	}
	
	private void drawReturnArr(Canvas canvas, Paint paint, float drwLeft, float drwTop, float drwRight, float drwBottom, float bgHeight) {
		if (progress >= nodes[5]) {
			Path path = new Path();
			path.moveTo(0.0125f * bgHeight, 0.500f * bgHeight);
			path.lineTo(0.0875f * bgHeight, 0.450f * bgHeight);
			path.lineTo(0.0875f * bgHeight, 0.475f * bgHeight);
			path.lineTo(0.1400f * bgHeight, 0.475f * bgHeight);
			path.lineTo(0.1400f * bgHeight, 0.525f * bgHeight);
			path.lineTo(0.0875f * bgHeight, 0.525f * bgHeight);
			path.lineTo(0.0875f * bgHeight, 0.550f * bgHeight);
			
			Matrix m = new Matrix();
			switch (anchor) {
				case RecBar.ANCHOR_TOP: {
					m.postRotate(90, 0.0825f * bgHeight, 0.5f * bgHeight);
					m.postTranslate((drwRight + drwLeft) / 2 - 0.084f * bgHeight, drwTop - 0.4175f * bgHeight);
				} break;
				case RecBar.ANCHOR_RIGHT: {
					m.postRotate(180, 0.0825f * bgHeight, 0.5f * bgHeight);
					m.postTranslate(drwRight - 0.1650f * bgHeight, drwTop);
				} break;
				case RecBar.ANCHOR_BOTTOM: {
					m.postRotate(270, 0.0825f * bgHeight, 0.5f * bgHeight);
					m.postTranslate((drwRight + drwLeft) / 2 - 0.084f * bgHeight, drwTop - 0.0825f * bgHeight);
				} break;
				default: {
					m.postTranslate(drwLeft, drwTop);
				} break;
			}
			path.transform(m);
			
			paint.setColor(0xe6157ed7);
			canvas.drawPath(path, paint);
		}
	}
	
	private void drawProfile(Canvas canvas, Paint paint, float drwLeft, float drwTop, float drwRight, float drwBottom, float bgHeight) {
		float bR = 0.1500f * bgHeight * scale;
		float hR = 0.1059f * bgHeight * scale;
		float bmHeight = 0.3176f * bgHeight * scale;
		
		canvas.save();
		switch (anchor) {
			case RecBar.ANCHOR_TOP: {
				canvas.rotate(-30, (drwRight + drwLeft) / 2 , drwTop); 
				paint.setColor(0xe6ffffff);
				float bmLeft = drwLeft + bgHeight / 2 - (bgHeight / 3 + bmHeight / 2) * table[progress - nodes[4]];
				RectF rect = new RectF(bmLeft - bR, drwTop - bR, bmLeft + bR, drwTop + bR);
				canvas.drawArc(rect, 90, -180, true, paint);
				
				Xfermode backM = paint.getXfermode();
				paint.setXfermode(new PorterDuffXfermode(Mode.SRC_OUT));
				paint.setColor(0);
				canvas.drawCircle(bmLeft + bmHeight - hR, drwTop, hR, paint);
				paint.setXfermode(backM);
				
				paint.setColor(0x9a009dd9);
				canvas.drawCircle(bmLeft + bmHeight - hR, drwTop, hR, paint);
				paint.setColor(0xe6ffffff);
				canvas.drawCircle(bmLeft + bmHeight - hR, drwTop, hR, paint);
			} break;
			case RecBar.ANCHOR_RIGHT: {
				canvas.rotate(-30, drwRight , (drwBottom + drwTop) / 2); 
				paint.setColor(0xe6ffffff);
				float bmTop = drwTop + bgHeight / 2 - (bgHeight / 3 + bmHeight / 2) * table[progress - nodes[4]];
				RectF rect = new RectF(drwRight - bR, bmTop + bmHeight - bR, drwRight + bR, bmTop + bmHeight + bR);
				canvas.drawArc(rect, 180, 180, true, paint);
				
				Xfermode backM = paint.getXfermode();
				paint.setXfermode(new PorterDuffXfermode(Mode.SRC_OUT));
				paint.setColor(0);
				canvas.drawCircle(drwRight, bmTop + hR, hR, paint);
				paint.setXfermode(backM);
				
				paint.setColor(0x9a009dd9);
				canvas.drawCircle(drwRight, bmTop + hR, hR, paint);
				paint.setColor(0xe6ffffff);
				canvas.drawCircle(drwRight, bmTop + hR, hR, paint);
			} break;
			case RecBar.ANCHOR_BOTTOM: {
				canvas.rotate(30, (drwRight + drwLeft) / 2 , drwBottom); 
				paint.setColor(0xe6ffffff);
				float bmLeft = drwLeft + bgHeight / 2 - (bgHeight / 3 + bmHeight / 2) * table[progress - nodes[4]];
				RectF rect = new RectF(bmLeft + bmHeight - bR, drwBottom -bR , bmLeft + bmHeight + bR, drwBottom + bR);
				canvas.drawArc(rect, 90, 180, true, paint);
				
				Xfermode backM = paint.getXfermode();
				paint.setXfermode(new PorterDuffXfermode(Mode.SRC_OUT));
				paint.setColor(0);
				canvas.drawCircle(bmLeft + hR, drwBottom, hR, paint);
				paint.setXfermode(backM);
				
				paint.setColor(0x9a009dd9);
				canvas.drawCircle(bmLeft + hR, drwBottom, hR, paint);
				paint.setColor(0xe6ffffff);
				canvas.drawCircle(bmLeft + hR, drwBottom, hR, paint);
			} break;
			default: {
				canvas.rotate(30, drwLeft, (drwBottom + drwTop) / 2); 
				paint.setColor(0xe6ffffff);
				float bmTop = drwTop + bgHeight / 2 - (bgHeight / 3 + bmHeight / 2) * table[progress - nodes[4]];
				RectF rect = new RectF(drwLeft - bR, bmTop + bmHeight - bR, drwLeft + bR, bmTop + bmHeight + bR);
				canvas.drawArc(rect, 180, 180, true, paint);
				
				Xfermode backM = paint.getXfermode();
				paint.setXfermode(new PorterDuffXfermode(Mode.SRC_OUT));
				paint.setColor(0);
				canvas.drawCircle(drwLeft, bmTop + hR, hR, paint);
				paint.setXfermode(backM);
				
				paint.setColor(0x9a009dd9);
				canvas.drawCircle(drwLeft, bmTop + hR, hR, paint);
				paint.setColor(0xe6ffffff);
				canvas.drawCircle(drwLeft, bmTop + hR, hR, paint);
			} break;
		}
		canvas.restore();
	}
	
	private void drawRec(Canvas canvas, Paint paint, float drwLeft, float drwTop, float drwRight, float drwBottom, float bgHeight) {
		String label;
		if (bar.isInEditMode()) {
			label = String.valueOf(new char[] {0x5f55, 0x5236});
		} else {
			int resId = R.getStringRes(getContext(), "srec_recbar_menu2");
			label = getContext().getString(resId);
		}
		String[] labels = label.split("\n");
		float width = 0;
		float[] widths = new float[labels.length];
		float textSize = 0.1853f * bgHeight * scale;
		paint.setTextSize(textSize);
		for (int i = 0; i < labels.length; i++) {
			widths[i] = paint.measureText(labels[i]);
			if (widths[i] > width) {
				width = widths[i];
			}
		}
		float height = textSize * labels.length + paint.getFontMetrics().bottom;
		float iR = 0.0706f * bgHeight * scale;
		width = width < 2 * iR ? 2 * iR : width;
		
		float bmTop;
		float bmLeft;
		switch (anchor) {
			case RecBar.ANCHOR_TOP: {
				bmTop = (drwTop + bgHeight / 3 - height / 2 - iR) * table[progress - nodes[4]];
				bmLeft = (drwRight + drwLeft) / 2 - width / 2;
			} break;
			case RecBar.ANCHOR_RIGHT: {
				bmTop = (drwTop + drwBottom - iR - height) / 2;
				bmLeft = drwRight - (bgHeight / 3 + width / 2) * table[progress - nodes[4]];
			} break;
			case RecBar.ANCHOR_BOTTOM: {
				bmTop = drwBottom - (bgHeight / 3 + height / 2 + iR) * table[progress - nodes[4]];
				bmLeft = (drwRight + drwLeft) / 2 - width / 2;
			} break;
			default: {
				bmTop = (drwTop + drwBottom - iR - height) / 2;
				bmLeft = (drwLeft + bgHeight / 3 - width / 2) * table[progress - nodes[4]];
			} break;
		}
		
		paint.setColor(0xe6d20202);
		canvas.drawCircle(bmLeft + width / 2, bmTop + iR, iR, paint);
		paint.setColor(0xe6ffffff);
		for (int i = 0; i < labels.length; i++) {
			canvas.drawText(labels[i], bmLeft + (width - widths[i]) / 2, bmTop + iR * 2 + i * textSize - paint.getFontMetrics().top, paint);
		}
	}
	
	private void drawVideoCenter(Canvas canvas, Paint paint, float drwLeft, float drwTop, float drwRight, float drwBottom, float bgHeight) {
		float bmWidth = 0.3441f * bgHeight * scale;
		float bmHeight = 0.2382f * bgHeight * scale;
		float bmTop;
		float bmLeft;
		Matrix m = new Matrix();
		canvas.save();
		switch (anchor) {
			case RecBar.ANCHOR_TOP: {
				bmTop = drwTop - bmHeight / 2;
				bmLeft = drwLeft + bgHeight / 2 + (bgHeight / 3 - bmWidth / 2) * table[progress - nodes[4]];
				canvas.rotate(30, (drwRight + drwLeft) / 2, drwTop);
				m.postRotate(-90, bmWidth / 2, bmHeight / 2);
			} break;
			case RecBar.ANCHOR_RIGHT: {
				bmTop = drwTop + bgHeight / 2 + (bgHeight / 3 - bmHeight / 2) * table[progress - nodes[4]];
				bmLeft = drwRight - bmWidth / 2;
				canvas.rotate(30, drwRight, (drwTop + drwBottom) / 2);
			} break;
			case RecBar.ANCHOR_BOTTOM: {
				bmTop = drwBottom - bmHeight / 2;
				bmLeft = drwLeft + bgHeight / 2 + (bgHeight / 3 - bmWidth / 2) * table[progress - nodes[4]];
				canvas.rotate(-30, (drwRight + drwLeft) / 2, drwBottom);
				m.postRotate(90, bmWidth / 2, bmHeight / 2);
			} break;
			default: {
				bmTop = drwTop + bgHeight / 2 + (bgHeight / 3 - bmHeight / 2) * table[progress - nodes[4]];
				bmLeft = drwLeft - bmWidth / 2;
				canvas.rotate(-30, drwLeft, (drwTop + drwBottom) / 2);
			} break;
		}
		m.postTranslate(bmLeft, bmTop);
		
		Path path = new Path();
		bgHeight *= scale;
		path.moveTo(0, 0.0662f * bgHeight);
		RectF rect = new RectF(0, 0.0496f * bgHeight, 0.0331f * bgHeight, 0.0827f * bgHeight);
		path.arcTo(rect, 180, 90);
		path.lineTo(0.0331f * bgHeight, 0.0496f * bgHeight);
		path.lineTo(0.0331f * bgHeight, 0.0331f * bgHeight);
		rect = new RectF(0.0331f * bgHeight, 0, 0.0662f * bgHeight, 0.0662f * bgHeight);
		path.arcTo(rect, 180, 90);
		path.lineTo(0.2316f * bgHeight, 0);
		rect = new RectF(0.1985f * bgHeight, 0, 0.2647f * bgHeight, 0.0662f * bgHeight);
		path.arcTo(rect, 270, 90);
		path.lineTo(0.2647f * bgHeight, 0.0574f * bgHeight);
		path.lineTo(0.3287f * bgHeight, 0.0276f * bgHeight);
		path.lineTo(0.3441f * bgHeight, 0.0441f * bgHeight);
		path.lineTo(0.3441f * bgHeight, 0.2040f * bgHeight);
		path.lineTo(0.3287f * bgHeight, 0.2206f * bgHeight);
		path.lineTo(0.2647f * bgHeight, 0.1930f * bgHeight);
		path.lineTo(0.2647f * bgHeight, 0.2085f * bgHeight);
		rect = new RectF(0.2018f * bgHeight, 0.1765f * bgHeight, 0.2647f * bgHeight, 0.2382f * bgHeight);
		path.arcTo(rect, 0, 90);
		path.lineTo(0.0662f * bgHeight, 0.2382f * bgHeight);
		rect = new RectF(0.0331f * bgHeight, 0.1765f * bgHeight, 0.0993f * bgHeight, 0.2382f * bgHeight);
		path.arcTo(rect, 90, 90);
		path.lineTo(0.0331f * bgHeight, 0.1522f * bgHeight);
		rect = new RectF(0, 0.1202f * bgHeight, 0.0331f * bgHeight, 0.1522f * bgHeight);
		path.arcTo(rect, 90, 90);
		path.transform(m);
		paint.setColor(0xe6ffffff);
		canvas.drawPath(path, paint);
		
		path = new Path();
		path.moveTo(0.1147f * bgHeight, 0.0507f * bgHeight);
		path.lineTo(0.1952f * bgHeight, 0.1180f * bgHeight);
		path.lineTo(0.1147f * bgHeight, 0.1853f * bgHeight);
		path.transform(m);
		Xfermode backM = paint.getXfermode();
		paint.setXfermode(new PorterDuffXfermode(Mode.CLEAR));
		paint.setColor(0);
		canvas.drawPath(path, paint);
		paint.setXfermode(backM);
		paint.setColor(0x9a009dd9);
		canvas.drawPath(path, paint);
		canvas.restore();
	}
	
	public void show() {
		if (showingOrHiding) {
			return;
		}
		
		showingOrHiding = true;
		closingType = false;
		new Thread() {
			public void run() {
				int msg = MSG_SHOW_MENU;
				progress = -1;
				for (int i = 0; i < frameCount; i++) {
					handler.sendEmptyMessageDelayed(msg, frameInterval * i);
				}
			}
		}.start();
	}
	
	public void hide(final Runnable afterHide) {
		if (showingOrHiding) {
			return;
		}
		
		showingOrHiding = true;
		new Thread() {
			public void run() {
				int msg = MSG_HIDE_MENU;
				int count = frameCount - 1;
				progress = count + 1;
				for (int i = 0; i < count; i++) {
					handler.sendEmptyMessageDelayed(msg, frameInterval * i);
				}
				Message m = new Message();
				m.what = msg;
				m.obj = afterHide;
				handler.sendMessageDelayed(m, frameInterval * count);
			}
		}.start();
	}
	
	public boolean handleMessage(Message msg) {
		switch(msg.what) {
			case MSG_SHOW_MENU: {
				progress++;
				if (progress <= 0) {
					setVisibility(View.VISIBLE);
				}
				invalidate();
				if (progress >= frameCount - 1) {
					showingOrHiding = false;
					handler.removeMessages(MSG_AUTO_HIDE);
					handler.sendEmptyMessageDelayed(MSG_AUTO_HIDE, 3000);
				}
			} break;
			case MSG_HIDE_MENU : {
				progress--;
				invalidate();
				if (progress <= 0) {
					showingOrHiding = false;
					setVisibility(View.GONE);
					if (msg.obj != null) {
						((Runnable) msg.obj).run();
					}
				}
			} break;
			case MSG_AUTO_HIDE: {
				if (visibility == View.VISIBLE) {
					bar.onCloseRecMenu();
				}
			} break;
		}
		return false;
	}
	
	protected boolean onTouchEvent(final MotionEvent event) {
		if (showingOrHiding) {
			return false;
		}
		
		if (touched) {
			handler.removeMessages(MSG_AUTO_HIDE);
			handler.sendEmptyMessageDelayed(MSG_AUTO_HIDE, 3000);
		}
		
		switch (event.getAction()) {
			case MotionEvent.ACTION_DOWN: {
				touched = isTouched(event);
				return touched;
			}
			case MotionEvent.ACTION_MOVE: {
				touched = isTouched(event);
				if (!touched) {
					setVisibility(View.GONE);
					bar.getIcon().setVisibility(View.VISIBLE);
				}
				return false;
			}
			case MotionEvent.ACTION_UP: {
				if (touched) {
					touched = false;
					return onUp(event);
				}
			}
		}
		
		return false;
	}

	private boolean isTouched(MotionEvent e) {
		float centerX;
		float centerY;
		switch (anchor) {
			case RecBar.ANCHOR_TOP: {
				centerX = (right + left) / 2;
				centerY = 0;
			}
			break;
			case RecBar.ANCHOR_RIGHT: {
				centerX = right;
				centerY = (bottom + top) / 2;
			}
			break;
			case RecBar.ANCHOR_BOTTOM: {
				centerX = (right + left) / 2;
				centerY = bottom;
			}
			break;
			default: {
				centerX = 0;
				centerY = (bottom + top) / 2;
			}
			break;
		}

		float xDis = centerX - e.getX();
		float yDis = centerY - e.getY();
		float distance = xDis * xDis + yDis * yDis;
		return (distance < boundary);
	}

	private boolean onUp(MotionEvent e) {
		switch (anchor) {
			case RecBar.ANCHOR_TOP: return onTopUp(e.getX(), e.getY());
			case RecBar.ANCHOR_RIGHT: return onRightUp(e.getX(), e.getY());
			case RecBar.ANCHOR_BOTTOM: return onBottomUp(e.getX(), e.getY());
			default: return onLeftUp(e.getX(), e.getY());
		}
	}

	private boolean onLeftUp(float x, float y) {
		float centerX = 0;
		float centerY = (bottom + top) / 2;
		float xDis = x - centerX;
		float yDis = centerY - y;
		float distance = xDis * xDis + yDis * yDis;
		float backDis = boundary / 9;

		if (distance >= boundary) {
			return false;
		} else if (distance <= backDis) {
			bar.onCloseRecMenu();
		} else if (0.32f * xDis < yDis) {
			bar.onShowMyVideo();
		} else if (0.32f * xDis < -yDis) {
			closingType = true;
			bar.onShowVideoCenter();
		} else {
			bar.onStartRecord();
		}
		return true;
	}

	private boolean onTopUp(float x, float y) {
		float centerX = (right + left) / 2;
		float centerY = 0;
		float xDis = centerX - x;
		float yDis = y - centerY;
		float distance = xDis * xDis + yDis * yDis;
		float backDis = boundary / 9 ;

		if (distance >= boundary) {
			return false;
		} else if (distance <= backDis) {
			bar.onCloseRecMenu();
		} else if (0.32f * yDis < xDis) {
			closingType = true;
			bar.onShowMyVideo();
		} else if (0.32f * yDis < -xDis) {
			bar.onShowVideoCenter();
		} else {
			bar.onStartRecord();
		}
		return true;
	}

	private boolean onRightUp(float x, float y) {
		float centerX = right;
		float centerY = (bottom + top) / 2;
		float xDis = centerX - x;
		float yDis = centerY - y;
		float distance = xDis * xDis + yDis * yDis;
		float backDis = boundary / 9 ;

		if (distance >= boundary) {
			return false;
		} else if (distance <= backDis) {
			bar.onCloseRecMenu();
		} else if (0.32f * xDis < yDis) {
			closingType = true;
			bar.onShowMyVideo();
		} else if (0.32f * xDis < -yDis) {
			bar.onShowVideoCenter();
		} else {
			bar.onStartRecord();
		}
		return true;
	}

	private boolean onBottomUp(float x, float y) {
		float centerX = (right + left) / 2;
		float centerY = bottom;
		float xDis = centerX - x;
		float yDis = centerY - y;
		float distance = xDis * xDis + yDis * yDis;
		float backDis = boundary / 9 ;

		if (distance >= boundary) {
			return false;
		} else if (distance <= backDis) {
			bar.onCloseRecMenu();
		} else if (0.32f * yDis < xDis) {
			bar.onShowMyVideo();
		} else if (0.32f * yDis < -xDis) {
			closingType = true;
			bar.onShowVideoCenter();
		} else {
			bar.onStartRecord();
		}
		return true;
	}
	
}
