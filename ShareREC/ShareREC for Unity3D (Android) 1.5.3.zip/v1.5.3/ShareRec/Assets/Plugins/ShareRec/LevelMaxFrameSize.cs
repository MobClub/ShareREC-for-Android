﻿namespace cn.sharerec {
#if UNITY_ANDROID
	public enum LevelMaxFrameSize {
		LEVEL_480_360 = 0,
		LEVEL_1280_720 = 1,
		LEVEL_1920_1080 = 2
	}
#endif
}
